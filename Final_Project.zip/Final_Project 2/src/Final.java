import javax.swing.*;

public class Final {
	public static void main(String[] args) {
		
		Login frame = new Login();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
}
